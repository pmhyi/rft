<?php

//define("DBNAME", '');
//define("DBUSER", '');
//define("DBPWD", '');
//define("DBHOST", 'localhost');
define("LOGFILE", "protected/log/" . date('Y-M-D') . ".log");//ide ír dátumal

//======================== LOGGER ====================================================================================

class MainLogger
{
  private $mailAddress = "sajat@email.hu";
    
  public static function log($str)
  {
     if (!file_exists(LOGFILE))
     {
       if ($fp = fopen(LOGFILE, 'w')) 
       {
         fprintf($fp, "%s\n", time()." - ".$str);
       }
     }
     else
     {
       if ($fp = fopen(LOGFILE, 'a+')) 
       {
         fprintf($fp, "%s\n", time()." - ".$str);
       }
     }
  }
  
  public function error($estr)
  {
     if (!file_exists(LOGFILE))
     {
       if ($fp = fopen(LOGFILE, 'w')) 
       {
         fprintf($fp, "%s\n", "Error::" . time()." - ".$estr);
       }
     }
     else
     {
       if ($fp = fopen(LOGFILE, 'a+')) 
       {
         fprintf($fp, "%s\n", "Error:: " . time()." - ".$estr);
       }
     }
     mail($this -> mailAddress, "VFSite Error", 
             date('y-m-d') . " - " . time() . " - " . $estr);
  }
  
}

//======================== FILEHANDLER ===============================================================================

class fileHandler
{
  private $DocumentRoot = 'abstract/';
   
  public function createName($Name) {
      return $this -> DocumentRoot . rand(10,100000) . preg_replace(array("/\s+/", "/[^-\.\w]+/"),
                           array("_", ""),
                           trim($Name));
  }
   
  public function CHaddFile($FILES, $fileName)
  {
   try
   {                 
     MainLogger::log("File (".$FILES['abstract']['tmp_name'].") uploading. New name (".$fileName.")");
     move_uploaded_file($FILES['abstract']['tmp_name'], $fileName);
     chmod($fileName, 0755);
     MainLogger::log("File uploaded");
     return 0;
   }
   catch (Exception $EX)
   {
     MainLogger::error("Error::File (".$FILES['abstract']['tmp_name'].") uploading. New name (".$this -> DocumentRoot . $fileName.")");
     return 1;
   }
  }  
}

//======================== DBHANDLER =================================================================================

class DBHandler
{
   public function connectDB()
   {
    try
    {
      MainLogger::log("Database connect starting");
      $mysql_id = mysql_connect(DBHOST, DBUSER, DBPWD);
      mysql_select_db(DBNAME);
      MainLogger::log("Database connect finished");
      return $mysql_id;
    }
    catch (Exception $EX)
    {
      MainLogger::error("Error::" . $EX);
      return "connect_error";
    }
   }

  public function Query($query)
  {
    try
    {
      MainLogger::log("Exec query (".$query.")");
      mysql_query($query);
      MainLogger::log("Query finished");
      return 0;
    }
    catch (Exception $EX)
    {
      MainLogger::error("Error::" . $EX);
      return 1;
    }
  }
  
  public function RQuery($query)
  {
    try
    {
      MainLogger::log("Exec select query");
      $arr = array();
      $result = mysql_query($query);
      while ($row = mysql_fetch_array($result))
      {
        $arr[] = $row;
      }
      MainLogger::log("Select query finished...");
      return $arr;
    }
    catch (Exception $EX)
    {
      MainLogger::error("Error::" . $EX);
      return $arr;
    }
  }
  
  public function in($datalist, $uid0, $field0) {
  foreach($datalist as &$reccs)
  {
    if ($reccs[$field0] == $uid0) {
       return true;
    }
  }
  return false;
}
  
  public function close($mysql_id)
  {
    mysql_close($mysql_id);
  }  
}

?>
