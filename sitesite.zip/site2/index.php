<?php 
//error_reporting(1);
include_once("protected/controller/IndexController.php");
$indexcontroll=new IndexController();
$indexcontroll->start();

