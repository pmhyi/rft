-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Hoszt: 127.0.0.1
-- Létrehozás ideje: 2016. Ápr 05. 12:09
-- Szerver verzió: 5.6.17
-- PHP verzió: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Adatbázis: `teszt`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `lead` text COLLATE utf8_hungarian_ci,
  `mid` int(11) DEFAULT NULL,
  `content` text COLLATE utf8_hungarian_ci,
  `moddate` datetime DEFAULT NULL,
  `createdate` date DEFAULT NULL,
  `leadpic` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=6 ;

--
-- A tábla adatainak kiíratása `article`
--

INSERT INTO `article` (`id`, `title`, `lead`, `mid`, `content`, `moddate`, `createdate`, `leadpic`) VALUES
(1, 'Dinamikus Webprogramozás', 'Lead szöveg', 1, 'php programozás', NULL, NULL, NULL),
(2, 'Mesterséges intelligencia', 'Szöveges lead', 1, 'c# programozás keretrendszerrel', NULL, NULL, NULL),
(3, 'Xml alapismeretek', 'Lead szöveg', 1, 'xml struktúra, lekérdezések,schema', NULL, NULL, NULL),
(4, 'Admin', 'elérhetőség', 4, 'Sajnos ez az adat még nem elérhető', NULL, NULL, NULL),
(5, 'Szerkesztő elérhetőségei', 'elérhető', 4, 'Nem elérhető :(', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `konyvek`
--

CREATE TABLE IF NOT EXISTS `konyvek` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cim` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `szerzo` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `leiras` text COLLATE utf8_hungarian_ci,
  `borito` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=4 ;

--
-- A tábla adatainak kiíratása `konyvek`
--

INSERT INTO `konyvek` (`id`, `cim`, `szerzo`, `leiras`, `borito`) VALUES
(1, 'Jungle Book', 'R. Kipling', 'A classic book.', NULL),
(2, 'Moonwalker', 'J. Walker', NULL, NULL),
(3, 'PHP for Dummies', 'Some smart Guy', NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `serial` int(11) DEFAULT NULL,
  `link` text COLLATE utf8_hungarian_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=6 ;

--
-- A tábla adatainak kiíratása `menu`
--

INSERT INTO `menu` (`id`, `title`, `serial`, `link`) VALUES
(1, 'Main Page', 1, NULL),
(2, 'Books', 2, NULL),
(3, 'About', 5, NULL),
(4, 'Contact', 4, NULL),
(5, 'Links', 3, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
