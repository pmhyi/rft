<?php
define ('DBUSER',"root");
define ('DBPWD',"");
define ('DBHOST',"localhost");
define ('DBNAME',"test2");
//require_once 'protected/core/Logger.php';
class coreDatabase{
    
	public function connect()
	{
		$d=mysql_connect(DBHOST, DBUSER, DBPWD);
		mysql_select_db(DBNAME);
		return $d;
	}
	
	public function close($id)
	{
                mysql_close($id);
	}
	
	public function query($query)
	{
                $array=array();
		$result=mysql_query($query);
		
		if(!$result) 
		{
			die('Could not connect: '.mysql_error());
		}
		
		while($row=mysql_fetch_assoc($result))
		{
			$array[]=$row;
		}
		return $array;
		
	}
	
	public function post($query)
	{
                $array=array();
		$result=mysql_query($query);
		
		if(!$result) 
		{
			die('Could not connect: '.mysql_error());
		}
		
		while($row=mysql_fetch_assoc($result))
		{
			$array[]=$row;
		}
		return $array;
		
	}
	
}

