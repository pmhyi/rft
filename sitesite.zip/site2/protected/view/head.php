<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta http-equiv="Content-Language" content="hu" />
<meta name="robots" content="index, follow, all" />
<meta name="doc-type" content="Web Page" />
<meta name="description" content="http://.../" />
<meta name="keywords" content="">

<title>Dinweb 2 site</title>
<link href="public/css/style.css" rel="stylesheet" type="text/css" />
</head>

