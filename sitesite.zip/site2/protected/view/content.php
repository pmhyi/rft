<div id="content">
    <?php foreach ($articlelist as $article){
        echo '<div id="cim"><a href="index.php?d=2/'.$article['id'].'">'.$article['title'].'</a></div>'
           . '<div id="lead">'.$article['lead'].'</div><hr><br>';
    }
?>   
</div>

