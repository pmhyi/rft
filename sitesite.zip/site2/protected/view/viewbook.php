<html>
<head></head>

<body>

<?php 

	echo 'Title:' . $book[cim] . '<br/>';
	echo 'Author:' . $book[szerzo] . '<br/>';
	echo 'Description:' . $book[leiras] . '<br/>';

?>

</body>
</html>