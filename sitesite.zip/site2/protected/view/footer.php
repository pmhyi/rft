<div id="footer">
    Lábléc
</div>
</div>
</body>
</html>