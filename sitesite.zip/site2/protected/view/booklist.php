<html>
<head></head>

<body>

<table>
	<tr><td>Title</td><td>Author</td><td>Description</td></tr>
	<?php 

		foreach ($books as $title => $book)
		{
			echo '<tr><td><a href="index.php?book='.$book[cim].'">'.$book[cim].'</a></td><td>'.$book[szerzo].'</td><td>'.$book[leiras].'</td></tr>';
		}

	?>
</table>

</body>
</html>