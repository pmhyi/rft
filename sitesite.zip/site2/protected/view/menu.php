<div id="menu">
    <ul>
       <?php   
        foreach($menupontok as $menu){
         echo '<li><a href="index.php?d='.$menu['serial'].'">'.$menu['title'].'</a></li>';        
        }               
        ?>
    </ul>
</div> 