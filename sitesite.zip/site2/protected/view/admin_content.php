<div id="content">
        
<h1>Cikk felviteli adatok megadása</h1>
<fieldset>
    <legend>Új cikk</legend>
    <form action="protected/model/addarticle.php" method="post" />
<table>
<tr>
<td>Cím:</td><td><input type="text" name="title" /><br /></td>
</tr>
<tr>
<td>Lead:</td><td><input type="text" name="lead" /><br /></td>
</tr>
<tr>
<td>Tartalom:</td><td><input type="text" name="content" /><br /></td>
</tr>
<tr>
<td>Módosítás dátuma:</td><td><input type="date" name="moddate" /><br /></td>
</tr>
<tr>
<td>Létrehozás dátuma:</td><td><input type="date" name="createdate" /><br /></td>
</tr>
<tr>
<td>Borító feltöltése:</td><td><input type="file" name="leadpic" /><br /></td>
</tr>
</table>
<input type="submit" value="Új cikk hozzáadása">
    </form>
</fieldset>
</div>

