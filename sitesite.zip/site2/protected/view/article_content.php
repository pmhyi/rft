<div id="content">
    <?php foreach ($article as $article){
        echo '<div id="cim">'.$article['title'].'</div><div id="content">'.$article['content'].'</div>
		   <div id="leadpic">'.$article['leadpic'].'</div><hr><br>';
    }
?>   
</div>

