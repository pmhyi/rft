<html>
<body>
<?php
$con = mysql_connect("localhost","root","");

if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("test2", $con);
 
  function GetImageExtension($imagetype)
   	 {
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return false;
       }
     }
	 
	 
	 
if (!empty($_FILES["leadpic"]["name"])) {

	$file_name=$_FILES["leadpic"]["name"];
	$temp_name=$_FILES["leadpic"]["tmp_name"];
	$imgtype=$_FILES["leadpic"]["type"];
	$ext= GetImageExtension($imgtype);
	$imagename=date("d-m-Y")."-".time().$ext;
	$target_path = "public/images/".$imagename;
	

if(move_uploaded_file($temp_name, $target_path)) {
	$sql="INSERT INTO `article` (`id`, `title`, `lead`, `mid`, `content`, `moddate`, `createdate`, `leadpic`) VALUES ('', '$_POST[title]', '$_POST[lead]', '1', '$_POST[content]', '$_POST[moddate]', '$_POST[createdate]', '".$target_path."')";
 

echo "1 cikk hozzáadva";
 

	
}else{

   exit("Error While uploading image on the server");
} 

}
mysql_close($con)

?>
</body>
</html>