<html>
<body>
<?php
$con = mysql_connect("localhost","root","");

if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("test2", $con);
 
 
$sql="INSERT INTO `article` (`id`, `title`, `lead`, `mid`, `content`, `moddate`, `createdate`, `leadpic`) VALUES ('', '$_POST[title]', '$_POST[lead]', '1', '$_POST[content]', '$_POST[moddate]', '$_POST[createdate]', '$_POST[leadpic]')";
 
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "1 cikk hozzáadva";
 
mysql_close($con)
?>
</body>
</html>