<?php
include_once("protected/core/Database.php");

class MenuModel {
    public $db;
	
	public function __construct()  
    {  
        $this->db = new coreDatabase();

    } 
	public function getMenu()
	{
		$id=$this->db->connect();
		$lista=$this->db->query("SELECT serial, id,title FROM menu order by serial");
		$this->db->close($id);
		return $lista;
	}	
}

