<?php
include_once("protected/core/Database.php");

class DBModel {
    public $db;
	
	public function __construct()  
    {  
        $this->db = new coreDatabase();

    } 
	public function getBookList()
	{
		$id=$this->db->connect();
		$lista=$this->db->query("SELECT * FROM konyvek");
		$this->db->close($id);
		return $lista;
	}
	
	public function getBook($title)
	{
		$id=$this->db->connect();
		$lista=$this->db->query("SELECT * FROM konyvek WHERE cim='".$title."'");
		$this->db->close($id);
		return $lista;
	}
	
	
}

?>