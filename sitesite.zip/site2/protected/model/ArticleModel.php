<?php
include_once("protected/core/Database.php");
include_once("lib/MainLogel.php");

class ArticleModel {
    public $db;
	
	public function __construct()  
    {  
        $this->db = new coreDatabase();

    } 
	public function getArticle()//getMenuList()
	{
		try{
			
				MainLogger::log("db kapcsolat elindult");
		
				$lista=array();
				if(array_key_exists("d", $_GET) && $_GET["d"]==2){
				$id=$this->db->connect();
				$lista=$this->db->query("SELECT title,content,id from article where mid=".$_GET["d"]); //mid
				$this->db->close($id);
				}
				return $lista;
		}catch(Exception $e)
		{
			MainLogger::error("hiba...".$e);
		}
	}	
}

