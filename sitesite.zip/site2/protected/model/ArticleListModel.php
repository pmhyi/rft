<?php
include_once("protected/core/Database.php");
include_once("lib/MainLogel.php");

class ArticleListModel {
    public $db;
	
	public function __construct()  
    {  
        $this->db = new coreDatabase();

    } 
	public function getMenuList()
	{
		try{
			
				MainLogger::log("db kapcsolat elindult");
		
				$lista=array();
				if(array_key_exists("d", $_GET)){
				$id=$this->db->connect();
				$lista=$this->db->query("SELECT id,title,lead,leadpic,mid from article where mid=".$_GET["d"]);
				$this->db->close($id);
				}
				return $lista;
		}catch(Exception $e)
		{
			MainLogger::error("hiba...".$e);
		}
	}

public function getArticle()//getMenuList()
	{
		try{
			
				MainLogger::log("db kapcsolat elindult");
		
				$lista=array();
				if(array_key_exists("d", $_GET)){
				$id=$this->db->connect();
				$lista=$this->db->query("SELECT title,content,id, leadpic from article where mid=1"); //mid
				$this->db->close($id);
				}
				return $lista;
		}catch(Exception $e)
		{
			MainLogger::error("hiba...".$e);
		}
	}	
	
	public function postArticle()//getMenuList()
	{
		try{
			
				MainLogger::log("db kapcsolat elindult");
		
				$querystring=array();
				if(array_key_exists("d", $_GET)){
				$id=$this->db->connect();
				
				
				$title= isset($_POST['title']);
				$lead= isset($_POST['lead']);

				$content = isset($_POST['content']);
				$moddate = isset($_POST['moddate']);
				$createdate = isset($_POST['createdate']);
				$leadpic = isset($_POST['leadpic']);
				
				$querystring=("INSERT INTO `article` (`id`, `title`, `lead`, `mid`, `content`, `moddate`, `createdate`, `leadpic`) VALUES ('', '$title', '$lead', '1', '$content', '$moddate', '$createdate', '$leadpic');"); //mid
				$this->db->close($id);
				echo '<meta-http-equiv="refresh" content="0; URL=index.php?d=4">';
				}
				//return $querystring;
		}catch(Exception $e)
		{
			MainLogger::error("hiba...".$e);
		}
	}	
}

