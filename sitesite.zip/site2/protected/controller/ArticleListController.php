<?php
include_once("protected/model/ArticleListModel.php");

class ArticleListController {
	public $model;
	
	public function __construct()  
    {  
        $this->model = new ArticleListModel();

    } 	
	public function articleListosszerako()
	{
		if (!isset($_GET["d"]))
		{$_GET["d"] = 0;}
    switch($_GET["d"])
    {
      case 2:$article=$this->model->getArticle();
             include_once 'protected/view/article_content.php';break;

	  case 4:$article=$this->model->postArticle();
             include_once 'protected/view/admin_content.php';break;
			 
      default: $articlelist=$this->model->getMenuList();
             include_once 'protected/view/content.php';
    }
             
	}
}