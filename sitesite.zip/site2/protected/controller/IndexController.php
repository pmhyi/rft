<?php

class IndexController{
    public function start(){
        include_once 'protected/view/head.php';
        include_once 'protected/view/header.php';
		
        include_once 'protected/controller/MenuController.php';
        $menu=new MenuController();
        $menu->menuOsszerako();
		
        include_once 'protected/controller/ArticleListController.php';
        $articlelist=new ArticleListController();
        $articlelist->articleListosszerako();
		
		/*include_once 'protected/controller/ArticleController.php';
        $article=new ArticleController();
        $article->article_osszerako();
		*/
        include_once 'protected/view/footer.php';
    }
}

