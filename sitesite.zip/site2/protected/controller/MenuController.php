<?php
include_once("protected/model/MenuModel.php");

class MenuController {
	public $model;
	
	public function __construct()  
    {  
        $this->model = new MenuModel();

    } 
	
	public function menuOsszerako()
	{
             $menupontok=$this->model->getMenu();
             include_once 'protected/view/menu.php';
	}
}
