<?php
include_once("protected/model/ArticleModel.php");

class ArticleController {
	public $model;
	
	public function __construct()  
    {  
        $this->model = new ArticleModel();

    } 	
	public function article_osszerako()
	{
             $article=$this->model->getArticle();
             include_once 'protected/view/article_content.php';
	}
}