<?php



$dict = array(

'#kulcs1#' => 'szöveg1',
'#kulcs2#' => 'szöveg2'

)
?>