<?

$dict = array(

'#kulcs1#' => 'text1',
'#kulcs2#' => 'text2'

)

?>