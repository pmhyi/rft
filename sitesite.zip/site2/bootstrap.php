<?

if(!array_key_exists("d", $_GET)) {
  $_GET["d"] = 1;
}

require_once("lib/classes.php");

if ($_SESSION["lang"] == 1) {
  require_once('protected/en.php');
}
else {
  require_once('protected/hu.php');
}

$logger = new MainLogger("log/" . date('Y-M-D'). ".log");
$FH     = new FileHandler();

?>


