<?php
if ($_GET["d"] == 0) { 


      $dict["#kulcs1#"];


 } 